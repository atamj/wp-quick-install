<?php
/**
 * Template Accueil
 * * *
 * @package base_wp_underscores
 */
?><?php 
get_header();
 ?>